# TSN_PYTHON3_CONSOLE_EXAMPLES
Авторские консольные примеры Талипова С.Н. на Python 3

_Примеры на Python 3 с PyQt5 доступны официальным подписчикам курса из дополнительного репозитория_

Полная электронная версия для Android: https://play.google.com/store/apps/details?id=kz.proffix4.tsn.lectnb

Copyright (c) 2019, Talipov S.N.
All rights reserved.

BSD 3-Clause License


