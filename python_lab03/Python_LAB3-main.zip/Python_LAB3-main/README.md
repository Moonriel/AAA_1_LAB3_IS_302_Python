# Python_KDK10_LAB3
**Разработка кроссплатформенных приложений.**
**Задание 3**

![Screenshot](screenshot1_lab3.png)
![Screenshot](screenshot2_lab3.png)